﻿{
	"version": 1709166892,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/bg_-sheet0.png",
		"images/flappyframe-sheet0.png",
		"images/pipa__1_removebgpreview-sheet0.png",
		"images/pipa__2_removebgpreview-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}